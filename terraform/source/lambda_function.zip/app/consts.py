import os

TMP_DIR = os.getenv("TMP_DIR", "tmp")
REGION_NAME = os.environ["REGION_NAME"]
SET_ADDRESS = os.environ["SET_ADDRESS"]